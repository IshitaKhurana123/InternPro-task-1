// Global variables
let members = JSON.parse(localStorage.getItem("gymMembers")) || []
let trainers = JSON.parse(localStorage.getItem("gymTrainers")) || []
let equipment = JSON.parse(localStorage.getItem("gymEquipment")) || []
let plans = JSON.parse(localStorage.getItem("gymPlans")) || [
  { id: 1, name: "Basic", price: 29, duration: 1, features: ["Gym Access", "Locker Room"] },
  {
    id: 2,
    name: "Premium",
    price: 49,
    duration: 1,
    features: ["Gym Access", "Locker Room", "Group Classes", "Nutrition Consultation"],
  },
  {
    id: 3,
    name: "VIP",
    price: 79,
    duration: 1,
    features: [
      "Gym Access",
      "Locker Room",
      "Group Classes",
      "Personal Training",
      "Nutrition Consultation",
      "Massage Therapy",
    ],
  },
]

let currentEditId = null

// Initialize the application
document.addEventListener("DOMContentLoaded", () => {
  initializeApp()
  setupEventListeners()
  updateDashboard()
})

function initializeApp() {
  // Add sample data if none exists
  if (members.length === 0) {
    members = [
      {
        id: 1,
        name: "John Doe",
        email: "john@email.com",
        phone: "123-456-7890",
        plan: "premium",
        status: "active",
        joinDate: new Date().toISOString(),
      },
      {
        id: 2,
        name: "Jane Smith",
        email: "jane@email.com",
        phone: "098-765-4321",
        plan: "basic",
        status: "active",
        joinDate: new Date().toISOString(),
      },
      {
        id: 3,
        name: "Mike Johnson",
        email: "mike@email.com",
        phone: "555-123-4567",
        plan: "vip",
        status: "inactive",
        joinDate: new Date().toISOString(),
      },
    ]
    localStorage.setItem("gymMembers", JSON.stringify(members))
  }

  if (trainers.length === 0) {
    trainers = [
      {
        id: 1,
        name: "Sarah Wilson",
        specialization: "Weight Training",
        experience: 5,
        phone: "111-222-3333",
        status: "active",
      },
      {
        id: 2,
        name: "David Brown",
        specialization: "Cardio & HIIT",
        experience: 3,
        phone: "444-555-6666",
        status: "active",
      },
      {
        id: 3,
        name: "Lisa Garcia",
        specialization: "Yoga & Pilates",
        experience: 7,
        phone: "777-888-9999",
        status: "active",
      },
    ]
    localStorage.setItem("gymTrainers", JSON.stringify(trainers))
  }

  if (equipment.length === 0) {
    equipment = [
      { id: 1, name: "Treadmill #1", type: "cardio", status: "working", lastMaintenance: "2024-01-15" },
      { id: 2, name: "Bench Press", type: "strength", status: "working", lastMaintenance: "2024-01-10" },
      { id: 3, name: "Rowing Machine", type: "cardio", status: "maintenance", lastMaintenance: "2024-01-20" },
      { id: 4, name: "Leg Press", type: "strength", status: "working", lastMaintenance: "2024-01-12" },
    ]
    localStorage.setItem("gymEquipment", JSON.stringify(equipment))
  }

  // Save plans if they don't exist
  if (!localStorage.getItem("gymPlans")) {
    localStorage.setItem("gymPlans", JSON.stringify(plans))
  }

  // Load all data
  loadMembers()
  loadTrainers()
  loadEquipment()
  loadPlans()
}

function setupEventListeners() {
  // Navigation
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()
      const page = this.dataset.page
      showPage(page)
    })
  })

  // Menu toggle for mobile
  document.querySelector(".menu-toggle").addEventListener("click", () => {
    document.querySelector(".sidebar").classList.toggle("active")
  })

  // Form submissions
  document.getElementById("member-form").addEventListener("submit", handleMemberSubmit)
  document.getElementById("trainer-form").addEventListener("submit", handleTrainerSubmit)
  document.getElementById("equipment-form").addEventListener("submit", handleEquipmentSubmit)
  document.getElementById("plan-form").addEventListener("submit", handlePlanSubmit)

  // Close modals when clicking outside
  window.addEventListener("click", (e) => {
    if (e.target.classList.contains("modal")) {
      e.target.style.display = "none"
    }
  })
}

function showPage(pageId) {
  // Hide all pages
  document.querySelectorAll(".page").forEach((page) => {
    page.classList.remove("active")
  })

  // Show selected page
  document.getElementById(pageId).classList.add("active")

  // Update navigation
  document.querySelectorAll(".nav-link").forEach((link) => {
    link.classList.remove("active")
  })
  document.querySelector(`[data-page="${pageId}"]`).classList.add("active")

  // Update page title
  const titles = {
    dashboard: "Dashboard",
    members: "Member Management",
    trainers: "Trainer Management",
    equipment: "Equipment Management",
    plans: "Membership Plans",
    reports: "Reports & Analytics",
  }
  document.getElementById("page-title").textContent = titles[pageId]

  // Update dashboard when showing dashboard page
  if (pageId === "dashboard") {
    updateDashboard()
  }
}

function updateDashboard() {
  // Update statistics
  document.getElementById("total-members").textContent = members.length
  document.getElementById("total-trainers").textContent = trainers.filter((t) => t.status === "active").length
  document.getElementById("total-equipment").textContent = equipment.length

  // Calculate monthly revenue
  const monthlyRevenue = members
    .filter((m) => m.status === "active")
    .reduce((total, member) => {
      const plan = plans.find((p) => p.name.toLowerCase() === member.plan)
      return total + (plan ? plan.price : 0)
    }, 0)
  document.getElementById("monthly-revenue").textContent = `$${monthlyRevenue}`

  // Update reports
  document.getElementById("report-revenue").textContent = `$${monthlyRevenue}`
  document.getElementById("report-new-members").textContent = members.filter((m) => {
    const joinDate = new Date(m.joinDate)
    const now = new Date()
    return joinDate.getMonth() === now.getMonth() && joinDate.getFullYear() === now.getFullYear()
  }).length
  document.getElementById("report-active-memberships").textContent = members.filter((m) => m.status === "active").length
}

// Member Management
function loadMembers() {
  const tbody = document.getElementById("members-table")
  tbody.innerHTML = ""

  members.forEach((member) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td>${member.id}</td>
            <td>${member.name}</td>
            <td>${member.email}</td>
            <td>${member.phone}</td>
            <td>${member.plan}</td>
            <td><span class="status ${member.status}">${member.status}</span></td>
            <td>
                <button class="btn btn-warning" onclick="editMember(${member.id})">Edit</button>
                <button class="btn btn-danger" onclick="deleteMember(${member.id})">Delete</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

function openMemberModal() {
  currentEditId = null
  document.getElementById("member-modal-title").textContent = "Add Member"
  document.getElementById("member-form").reset()
  document.getElementById("member-modal").style.display = "block"
}

function closeMemberModal() {
  document.getElementById("member-modal").style.display = "none"
}

function handleMemberSubmit(e) {
  e.preventDefault()

  const memberData = {
    name: document.getElementById("member-name").value,
    email: document.getElementById("member-email").value,
    phone: document.getElementById("member-phone").value,
    plan: document.getElementById("member-plan").value,
    status: "active",
    joinDate: new Date().toISOString(),
  }

  if (currentEditId) {
    // Edit existing member
    const index = members.findIndex((m) => m.id === currentEditId)
    members[index] = { ...members[index], ...memberData }
  } else {
    // Add new member
    memberData.id = Date.now()
    members.push(memberData)
  }

  localStorage.setItem("gymMembers", JSON.stringify(members))
  loadMembers()
  closeMemberModal()
  updateDashboard()
}

function editMember(id) {
  const member = members.find((m) => m.id === id)
  if (member) {
    currentEditId = id
    document.getElementById("member-modal-title").textContent = "Edit Member"
    document.getElementById("member-name").value = member.name
    document.getElementById("member-email").value = member.email
    document.getElementById("member-phone").value = member.phone
    document.getElementById("member-plan").value = member.plan
    document.getElementById("member-modal").style.display = "block"
  }
}

function deleteMember(id) {
  if (confirm("Are you sure you want to delete this member?")) {
    members = members.filter((m) => m.id !== id)
    localStorage.setItem("gymMembers", JSON.stringify(members))
    loadMembers()
    updateDashboard()
  }
}

function searchMembers() {
  const searchTerm = document.getElementById("member-search").value.toLowerCase()
  const filteredMembers = members.filter(
    (member) =>
      member.name.toLowerCase().includes(searchTerm) ||
      member.email.toLowerCase().includes(searchTerm) ||
      member.phone.includes(searchTerm),
  )

  const tbody = document.getElementById("members-table")
  tbody.innerHTML = ""

  filteredMembers.forEach((member) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td>${member.id}</td>
            <td>${member.name}</td>
            <td>${member.email}</td>
            <td>${member.phone}</td>
            <td>${member.plan}</td>
            <td><span class="status ${member.status}">${member.status}</span></td>
            <td>
                <button class="btn btn-warning" onclick="editMember(${member.id})">Edit</button>
                <button class="btn btn-danger" onclick="deleteMember(${member.id})">Delete</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

// Trainer Management
function loadTrainers() {
  const tbody = document.getElementById("trainers-table")
  tbody.innerHTML = ""

  trainers.forEach((trainer) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td>${trainer.id}</td>
            <td>${trainer.name}</td>
            <td>${trainer.specialization}</td>
            <td>${trainer.experience} years</td>
            <td>${trainer.phone}</td>
            <td><span class="status ${trainer.status}">${trainer.status}</span></td>
            <td>
                <button class="btn btn-warning" onclick="editTrainer(${trainer.id})">Edit</button>
                <button class="btn btn-danger" onclick="deleteTrainer(${trainer.id})">Delete</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

function openTrainerModal() {
  currentEditId = null
  document.getElementById("trainer-form").reset()
  document.getElementById("trainer-modal").style.display = "block"
}

function closeTrainerModal() {
  document.getElementById("trainer-modal").style.display = "none"
}

function handleTrainerSubmit(e) {
  e.preventDefault()

  const trainerData = {
    name: document.getElementById("trainer-name").value,
    specialization: document.getElementById("trainer-specialization").value,
    experience: Number.parseInt(document.getElementById("trainer-experience").value),
    phone: document.getElementById("trainer-phone").value,
    status: "active",
  }

  if (currentEditId) {
    const index = trainers.findIndex((t) => t.id === currentEditId)
    trainers[index] = { ...trainers[index], ...trainerData }
  } else {
    trainerData.id = Date.now()
    trainers.push(trainerData)
  }

  localStorage.setItem("gymTrainers", JSON.stringify(trainers))
  loadTrainers()
  closeTrainerModal()
  updateDashboard()
}

function editTrainer(id) {
  const trainer = trainers.find((t) => t.id === id)
  if (trainer) {
    currentEditId = id
    document.getElementById("trainer-name").value = trainer.name
    document.getElementById("trainer-specialization").value = trainer.specialization
    document.getElementById("trainer-experience").value = trainer.experience
    document.getElementById("trainer-phone").value = trainer.phone
    document.getElementById("trainer-modal").style.display = "block"
  }
}

function deleteTrainer(id) {
  if (confirm("Are you sure you want to delete this trainer?")) {
    trainers = trainers.filter((t) => t.id !== id)
    localStorage.setItem("gymTrainers", JSON.stringify(trainers))
    loadTrainers()
    updateDashboard()
  }
}

// Equipment Management
function loadEquipment() {
  const tbody = document.getElementById("equipment-table")
  tbody.innerHTML = ""

  equipment.forEach((item) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td>${item.id}</td>
            <td>${item.name}</td>
            <td>${item.type}</td>
            <td><span class="status ${item.status}">${item.status}</span></td>
            <td>${item.lastMaintenance}</td>
            <td>
                <button class="btn btn-warning" onclick="editEquipment(${item.id})">Edit</button>
                <button class="btn btn-danger" onclick="deleteEquipment(${item.id})">Delete</button>
            </td>
        `
    tbody.appendChild(row)
  })
}

function openEquipmentModal() {
  currentEditId = null
  document.getElementById("equipment-form").reset()
  document.getElementById("equipment-modal").style.display = "block"
}

function closeEquipmentModal() {
  document.getElementById("equipment-modal").style.display = "none"
}

function handleEquipmentSubmit(e) {
  e.preventDefault()

  const equipmentData = {
    name: document.getElementById("equipment-name").value,
    type: document.getElementById("equipment-type").value,
    status: document.getElementById("equipment-status").value,
    lastMaintenance: new Date().toISOString().split("T")[0],
  }

  if (currentEditId) {
    const index = equipment.findIndex((e) => e.id === currentEditId)
    equipment[index] = { ...equipment[index], ...equipmentData }
  } else {
    equipmentData.id = Date.now()
    equipment.push(equipmentData)
  }

  localStorage.setItem("gymEquipment", JSON.stringify(equipment))
  loadEquipment()
  closeEquipmentModal()
  updateDashboard()
}

function editEquipment(id) {
  const item = equipment.find((e) => e.id === id)
  if (item) {
    currentEditId = id
    document.getElementById("equipment-name").value = item.name
    document.getElementById("equipment-type").value = item.type
    document.getElementById("equipment-status").value = item.status
    document.getElementById("equipment-modal").style.display = "block"
  }
}

function deleteEquipment(id) {
  if (confirm("Are you sure you want to delete this equipment?")) {
    equipment = equipment.filter((e) => e.id !== id)
    localStorage.setItem("gymEquipment", JSON.stringify(equipment))
    loadEquipment()
    updateDashboard()
  }
}

// Plans Management
function loadPlans() {
  const container = document.getElementById("plans-grid")
  container.innerHTML = ""

  plans.forEach((plan) => {
    const planCard = document.createElement("div")
    planCard.className = "plan-card"
    planCard.innerHTML = `
            <h3>${plan.name}</h3>
            <div class="plan-price">$${plan.price}<small>/month</small></div>
            <ul class="plan-features">
                ${plan.features.map((feature) => `<li>${feature}</li>`).join("")}
            </ul>
            <div style="display: flex; gap: 10px;">
                <button class="btn btn-warning" onclick="editPlan(${plan.id})">Edit</button>
                <button class="btn btn-danger" onclick="deletePlan(${plan.id})">Delete</button>
            </div>
        `
    container.appendChild(planCard)
  })
}

function openPlanModal() {
  currentEditId = null
  document.getElementById("plan-form").reset()
  document.getElementById("plan-modal").style.display = "block"
}

function closePlanModal() {
  document.getElementById("plan-modal").style.display = "none"
}

function handlePlanSubmit(e) {
  e.preventDefault()

  const planData = {
    name: document.getElementById("plan-name").value,
    price: Number.parseInt(document.getElementById("plan-price").value),
    duration: Number.parseInt(document.getElementById("plan-duration").value),
    features: document
      .getElementById("plan-features")
      .value.split(",")
      .map((f) => f.trim())
      .filter((f) => f),
  }

  if (currentEditId) {
    const index = plans.findIndex((p) => p.id === currentEditId)
    plans[index] = { ...plans[index], ...planData }
  } else {
    planData.id = Date.now()
    plans.push(planData)
  }

  localStorage.setItem("gymPlans", JSON.stringify(plans))
  loadPlans()
  closePlanModal()
  updateDashboard()
}

function editPlan(id) {
  const plan = plans.find((p) => p.id === id)
  if (plan) {
    currentEditId = id
    document.getElementById("plan-name").value = plan.name
    document.getElementById("plan-price").value = plan.price
    document.getElementById("plan-duration").value = plan.duration
    document.getElementById("plan-features").value = plan.features.join(", ")
    document.getElementById("plan-modal").style.display = "block"
  }
}

function deletePlan(id) {
  if (confirm("Are you sure you want to delete this plan?")) {
    plans = plans.filter((p) => p.id !== id)
    localStorage.setItem("gymPlans", JSON.stringify(plans))
    loadPlans()
    updateDashboard()
  }
}
