const express = require('express');
const router = express.Router();
const Trainer = require('../models/Trainer');

router.get('/', async (req, res) => {
    const trainers = await Trainer.find();
    res.json(trainers);
});

router.post('/', async (req, res) => {
    const newTrainer = new Trainer(req.body);
    await newTrainer.save();
    res.json(newTrainer);
});

module.exports = router;